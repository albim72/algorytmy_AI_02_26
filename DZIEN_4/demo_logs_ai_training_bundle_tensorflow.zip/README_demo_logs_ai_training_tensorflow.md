# Demo (TensorFlow): logi -> (1) klasteryzacja nienadzorowana -> (2) klasyfikacja siecią neuronową

Wersja „oparta na TensorFlow”:
- wektoryzacja tekstu: `tf.keras.layers.TextVectorization` (output_mode="tf-idf")
- klasteryzacja: KMeans zaimplementowany w czystym TensorFlow (bez scikit-learn)
- klasyfikacja: Keras MLP (Dense -> Dense -> Softmax)

## Pliki
- `synthetic_system_logs.log` – surowe logi (ok. 2500 linii)
- `demo_logs_unsupervised_then_supervised_tensorflow.py` – pełny kod
- `README_demo_logs_ai_training_tensorflow.md` – ten opis

## Jak uruchomić

```bash
pip install -U tensorflow
python demo_logs_unsupervised_then_supervised_tensorflow.py
```

Skrypt:
1) uczy warstwę wektoryzacji TF-IDF na logach,
2) robi KMeans (k=5),
3) wypisuje przykłady z klastrów (do „nazwania” klastrów przez człowieka),
4) trenuje małą sieć MLP, która przewiduje **ID klastra** dla nowych linii.

## Dlaczego TF-IDF na znakach?

Logi to „tekst z metadanymi”: `key=value`, kody `401/504`, tokeny `timeout`, `cache`, liczby, ścieżki plików.
N-gramy znakowe łapią te wzorce bez ręcznego pisania parserów.
