from __future__ import annotations
from collections import Counter
from typing import Iterable, Set, Tuple

Cell = Tuple[int, int]


def neighbors(cell: Cell) -> Iterable[Cell]:
    x, y = cell
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            yield x + dx, y + dy


def step(world: Set[Cell]) -> Set[Cell]:
    """
    Jeden krok w 'Grze Życia Maga'.
    Reguły (klasyczne Game of Life):
    - Żywa komórka przeżywa, jeśli ma 2 lub 3 sąsiadów.
    - Martwa komórka ożywa, jeśli ma dokładnie 3 sąsiadów.
    """
    counts = Counter()

    # Zlicz wszystkich sąsiadów żywych komórek
    for cell in world:
        for nb in neighbors(cell):
            counts[nb] += 1

    new_world: Set[Cell] = set()

    for cell, n in counts.items():
        if n == 3 or (n == 2 and cell in world):
            new_world.add(cell)

    return new_world


def print_world(world: Set[Cell], padding: int = 1) -> None:
    if not world:
        print("(pustka w eterze)")
        return

    xs = [x for x, _ in world]
    ys = [y for _, y in world]

    for y in range(min(ys) - padding, max(ys) + padding + 1):
        row = []
        for x in range(min(xs) - padding, max(xs) + padding + 1):
            row.append("█" if (x, y) in world else " ")
        print("".join(row))
    print("-" * 40)


if __name__ == "__main__":
    # Klasyczny 'glider' – mały wzór, który zaczyna 'płynąć' po planszy
    glider = {
        (1, 0),
        (2, 1),
        (0, 2), (1, 2), (2, 2),
    }

    world = glider
    print("== Start: Glider Maga ==")
    print_world(world)

    for i in range(1, 11):
        world = step(world)
        print(f"== Krok {i} ==")
        print_world(world)
