"""
Metaklasa + Protocol = RUNTIME VALIDATION DEMO
----------------------------------------------

Pokazuje, jak:
- użyć typing.Protocol jako "kontraktu",
- zbudować metaklasę, która przy tworzeniu klasy:
    * sprawdza, czy wszystkie wymagane metody/properties istnieją,
    * porównuje sygnatury metod (argumenty, nazwy),
    * porównuje typy w adnotacjach (prosto, ale wystarczająco efektownie),
- zablokować tworzenie klasy, która łamie kontrakt.

To jest realny, runtime'owy wpływ Protocol na klasy.
"""

from __future__ import annotations

import inspect
from typing import Protocol, runtime_checkable, get_type_hints, Any, Type


# ==========================
# 1. Definiujemy Protocol
# ==========================

@runtime_checkable
class ServiceProtocol(Protocol):
    timeout: float

    def execute(self, payload: dict[str, Any]) -> dict[str, Any]:
        ...


# ==========================
# 2. Metaklasa pilnująca kontraktu
# ==========================

class ProtocolEnforcer(type):
    """
    Metaklasa, która:
    - czyta atrybut __protocol__ z klasy,
    - waliduje klasę względem wskazanego Protocol,
    - jeśli są niezgodności → rzuca TypeError.

    Użycie:
        class MyService(metaclass=ProtocolEnforcer):
            __protocol__ = ServiceProtocol
            ...
    """

    def __new__(mcls, name, bases, namespace, **kwargs):
        cls = super().__new__(mcls, name, bases, namespace, **kwargs)

        protocol: Type[Protocol] | None = namespace.get("__protocol__", None)
        if protocol is None:
            # Klasa nie deklaruje kontraktu – nie walidujemy.
            return cls

        # 1) Sprawdzamy, czy cls jest strukturalnie zgodna z Protocol
        #    (runtime_checkable + isinstance)
        if not isinstance(cls(), protocol):  # może rzucić, jeśli init wymagający
            # tego nie robimy, bo __init__ może nie akceptować pustych argumentów
            pass

        # 2) Walidacja metod + pól po adnotacjach typów
        _validate_against_protocol(cls, protocol)

        return cls


def _validate_against_protocol(cls: Type[Any], protocol: Type[Any]) -> None:
    errors: list[str] = []

    # Typy z Protocol i z klasy
    proto_hints = get_type_hints(protocol, include_extras=True)
    cls_hints = get_type_hints(cls, include_extras=True)

    # --- Sprawdzamy pola/anotacje atrybutów ---
    for name, expected_type in proto_hints.items():
        # Metody będą też w proto_hints (type -> function), ale zajmiemy się nimi osobno.
        # Tu filtrujemy tylko nie-callable (proste pola jak timeout).
        attr_obj = getattr(protocol, name, None)
        if callable(attr_obj):
            # To jest metoda, pominiemy ją tutaj.
            continue

        if name not in cls_hints:
            errors.append(f"Brak adnotacji dla atrybutu '{name}' w klasie '{cls.__name__}'")
            continue

        actual_type = cls_hints[name]
        if actual_type != expected_type:
            errors.append(
                f"Niezgodny typ atrybutu '{name}' w klasie '{cls.__name__}': "
                f"oczekiwano {expected_type}, znaleziono {actual_type}"
            )

    # --- Sprawdzamy metody: obecność + sygnatura + typ zwracany ---
    for name, proto_attr in protocol.__dict__.items():
        if not callable(proto_attr):
            continue  # nie metoda

        if name.startswith("_"):
            continue  # pomijamy metody "prywatne" protokołu

        if not hasattr(cls, name):
            errors.append(f"Brak metody '{name}' wymaganej przez Protocol w klasie '{cls.__name__}'")
            continue

        cls_attr = getattr(cls, name)

        # sygnatura
        proto_sig = inspect.signature(proto_attr)
        cls_sig = inspect.signature(cls_attr)

        # Prosta walidacja: liczba i nazwy parametrów
        if len(proto_sig.parameters) != len(cls_sig.parameters):
            errors.append(
                f"Niezgodna liczba parametrów w metodzie '{name}' "
                f"(Protocol: {len(proto_sig.parameters)}, "
                f"klasa '{cls.__name__}': {len(cls_sig.parameters)})"
            )
        else:
            for (p_name, p_proto), (c_name, c_param) in zip(
                proto_sig.parameters.items(), cls_sig.parameters.items()
            ):
                if p_name != c_name:
                    errors.append(
                        f"Niezgodna nazwa parametru w metodzie '{name}': "
                        f"Protocol ma '{p_name}', klasa '{cls.__name__}' ma '{c_name}'"
                    )

        # typ zwracany
        proto_ret = get_type_hints(protocol).get(name, None)
        cls_ret = get_type_hints(cls).get(name, None)

        if proto_ret is not None and cls_ret is not None and proto_ret != cls_ret:
            errors.append(
                f"Niezgodny typ zwracany metody '{name}' "
                f"(Protocol: {proto_ret}, klasa '{cls.__name__}': {cls_ret})"
            )

    if errors:
        msg = (
            f"Klasa '{cls.__name__}' nie spełnia kontraktu Protocol "
            f"'{protocol.__name__}':\n - " + "\n - ".join(errors)
        )
        raise TypeError(msg)


# ==========================
# 3. Przykłady klas
# ==========================

class GoodService(metaclass=ProtocolEnforcer):
    __protocol__ = ServiceProtocol

    timeout: float = 1.5

    def execute(self, payload: dict[str, Any]) -> dict[str, Any]:
        print("[GoodService] Executing with payload:", payload)
        return {"status": "ok", "original": payload}


# Ta klasa narusza kontrakt na kilka sposobów:
# - timeout ma zły typ (int zamiast float),
# - execute ma zły typ zwracany (str zamiast dict[str, Any])
# - execute ma inne parametry (brak 'payload' albo zła nazwa)
try:
    class BadService(metaclass=ProtocolEnforcer):
        __protocol__ = ServiceProtocol

        timeout: int = 10  # zły typ

        def execute(self, data: dict[str, Any]) -> str:  # zła nazwa parametru i zwrot typu
            print("[BadService] Doing something...")
            return "oops"
except TypeError as e:
    print("Walidacja BadService nie powiodła się:")
    print(e)


# ==========================
# 4. Demo użycia
# ==========================

if __name__ == "__main__":
    service = GoodService()
    response = service.execute({"x": 42})
    print("Odpowiedź:", response)
