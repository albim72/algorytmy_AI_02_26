"""
Mini-język zaklęć w Pythonie – własne "słowo kluczowe" spell
-------------------------------------------------------------

Pozwala pisać kod w formie:

    mana = 3

    spell heal:
        print("Leczę bohatera")
        mana = mana - 1

    print("Mana po zaklęciu:", mana)

który NIE jest poprawnym Pythonem, ale my:

1. Wstępnie przetwarzamy tekst:
   spell heal:   -->   with spell("heal"):

2. Parsujemy wynik do AST.
3. Za pomocą SpellBlockTransformer:
   - odnajdujemy konstrukcje: with spell("..."):
   - wstrzykujemy dodatkowy kod (printy / logowanie etc.)

4. Kompilujemy i wykonujemy powstałe drzewo.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Dict, Any, Optional


# =========================================
# 1. Kontekst zaklęcia – zwykły context manager
# =========================================

@dataclass
class Spell:
    """Prosty context manager reprezentujący zaklęcie."""

    name: str

    def __enter__(self) -> None:
        print(f"[BEGIN SPELL: {self.name}]")

    def __exit__(self, exc_type, exc, tb) -> bool:
        if exc is not None:
            print(f"⚡ [SPELL ERROR: {self.name}] {exc}")
            # False → wyjątek dalej się propaguje
            return False
        print(f"[END SPELL: {self.name}]")
        return False


def spell(name: str) -> Spell:
    """Fabryka zaklęć – używana przez transformed kod."""
    return Spell(name)


# =========================================
# 2. Preprocesor: "spell heal:" → "with spell('heal'):"
# =========================================

def preprocess_spell_syntax(source: str) -> str:
    """
    Zamienia w kodzie linie postaci:

        spell heal:
            ...

    na:

        with spell('heal'):
            ...

    Zachowuje wcięcia.
    To jest *przed* parsowaniem do AST, bo Python sam z siebie
    nie rozumie słowa 'spell' jako instrukcji.
    """
    new_lines: list[str] = []

    for line in source.splitlines():
        # Zachowaj oryginalne wcięcie
        stripped = line.lstrip()
        indent = line[: len(line) - len(stripped)]

        if stripped.startswith("spell ") and stripped.rstrip().endswith(":"):
            # Wycinamy nazwę zaklęcia pomiędzy 'spell ' a ':'
            inner = stripped[len("spell "):].rstrip()
            # Usuwamy dwukropek na końcu
            if inner.endswith(":"):
                inner = inner[:-1].rstrip()

            # Tu można dodać bardziej zaawansowaną logikę (np. parametry)
            spell_name = inner

            new_line = f"{indent}with spell('{spell_name}'):\n"
            new_lines.append(new_line)
        else:
            # Zostawiamy linię bez zmian
            new_lines.append(line + "\n")

    return "".join(new_lines)


# =========================================
# 3. AST-transformer: wstrzyknięcie logiki do bloków spell
# =========================================

class SpellBlockTransformer(ast.NodeTransformer):
    """
    Odnajduje konstrukcje:

        with spell("heal"):
            ...

    i modyfikuje ich wnętrze, np. dodając logi na początku i końcu
    bloku zaklęcia.

    To jest już *prawdziwa* praca na AST – operujemy na węzłach.
    """

    def visit_With(self, node: ast.With) -> Any:
        # Najpierw rekurencyjnie odwiedź wnętrze (żeby nie zgubić niczego)
        self.generic_visit(node)

        if not node.items:
            return node

        first_item = node.items[0]
        ctx_expr = first_item.context_expr

        # Interesuje nas konstrukcja: with spell("..."):
        if (
            isinstance(ctx_expr, ast.Call)
            and isinstance(ctx_expr.func, ast.Name)
            and ctx_expr.func.id == "spell"
            and ctx_expr.args
            and isinstance(ctx_expr.args[0], ast.Constant)
            and isinstance(ctx_expr.args[0].value, str)
        ):
            spell_name = ctx_expr.args[0].value

            # Tworzymy dwa dodatkowe wyrażenia (printy)
            enter_msg = ast.Expr(
                value=ast.Call(
                    func=ast.Name(id="print", ctx=ast.Load()),
                    args=[
                        ast.Constant(
                            value=f"AST: wchodzę do bloku zaklęcia '{spell_name}'"
                        )
                    ],
                    keywords=[],
                )
            )
            exit_msg = ast.Expr(
                value=ast.Call(
                    func=ast.Name(id="print", ctx=ast.Load()),
                    args=[
                        ast.Constant(
                            value=f"AST: wychodzę z bloku zaklęcia '{spell_name}'"
                        )
                    ],
                    keywords=[],
                )
            )

            # Wstrzykujemy nowe linie na początek i koniec ciała bloku
            node.body = [enter_msg] + node.body + [exit_msg]

        return node


# =========================================
# 4. Funkcja uruchamiająca kod w "języku spell"
# =========================================

def run_spell_code(source: str, global_ns: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Przyjmuje kod źródłowy z użyciem 'spell' w stylu:

        mana = 3

        spell heal:
            print("Leczę bohatera")
            mana = mana - 1

        print("Mana po:", mana)

    1) Preprocesuje tekst do poprawnego Pythona.
    2) Parsuje do AST.
    3) Modyfikuje AST (SpellBlockTransformer).
    4) Kompiluje i wykonuje kod.
    5) Zwraca przestrzeń globalną po wykonaniu (można podejrzeć zmienne).
    """
    if global_ns is None:
        global_ns = {}

    # Preprocessing: własne pseudo-słowo kluczowe
    preprocessed = preprocess_spell_syntax(source)

    # Parsowanie do drzewa AST
    tree = ast.parse(preprocessed, filename="<spell-code>", mode="exec")

    # Transformacja AST – wstrzyknięcie dodatkowych instrukcji
    transformer = SpellBlockTransformer()
    transformed_tree = transformer.visit(tree)
    ast.fix_missing_locations(transformed_tree)

    # Przygotowanie przestrzeni nazw – zapewniamy dostęp do spell/Spell
    global_ns.setdefault("spell", spell)
    global_ns.setdefault("Spell", Spell)

    # Kompilacja i wykonanie
    code_obj = compile(transformed_tree, filename="<spell-code>", mode="exec")
    exec(code_obj, global_ns)

    return global_ns


# =========================================
# 5. Demo – możesz odpalić plik bezpośrednio
# =========================================

if __name__ == "__main__":
    demo_source = """
mana = 3

print("Mana startowa:", mana)

spell heal:
    print("   → Leczę bohatera...")
    mana = mana - 1

spell fireball:
    print("   → Rzucam kulę ognia!")
    mana = mana - 2

print("Mana po zaklęciach:", mana)
"""

    env = run_spell_code(demo_source)
    print("\\n[ZMIENNE KOŃCOWE]:")
    for k, v in env.items():
        if not k.startswith("__"):
            print(f"{k} = {v!r}")
