
print("[module_x] Reloaded module_x – VERSION 2!")

def greet():
    print("[module_x] Hello from version 2 — reloaded!")
