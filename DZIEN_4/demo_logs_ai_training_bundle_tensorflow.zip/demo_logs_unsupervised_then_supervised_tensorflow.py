\
"""
TensorFlow demo: logs -> (1) unsupervised clustering (TF KMeans) -> (2) supervised classification (Keras MLP)

Run:
  pip install -U tensorflow
  python demo_logs_unsupervised_then_supervised_tensorflow.py

Notes:
- We use TextVectorization(output_mode="tf-idf") to avoid hand-coded parsers.
- We implement a simple KMeans in pure TF (good enough for a live demo).
- Then we train an MLP to predict the discovered cluster id for new lines.
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path
import numpy as np
import tensorflow as tf


def load_lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines()


def tf_kmeans(x: tf.Tensor, k: int, iters: int = 20, seed: int = 42) -> tuple[tf.Tensor, tf.Tensor]:
    """
    Minimal KMeans in TensorFlow.

    Parameters
    ----------
    x:
        Float tensor [N, D]
    k:
        number of clusters
    iters:
        iterations
    seed:
        random seed

    Returns
    -------
    labels:
        int32 tensor [N]
    centroids:
        float32 tensor [K, D]
    """
    tf.random.set_seed(seed)
    n = tf.shape(x)[0]

    # Init centroids by sampling points
    idx = tf.random.shuffle(tf.range(n))[:k]
    centroids = tf.gather(x, idx)

    for _ in range(iters):
        # distances: [N, K] using squared euclidean distance
        x2 = tf.reduce_sum(tf.square(x), axis=1, keepdims=True)              # [N, 1]
        c2 = tf.reduce_sum(tf.square(centroids), axis=1, keepdims=True)      # [K, 1]
        xc = tf.matmul(x, centroids, transpose_b=True)                       # [N, K]
        dists = x2 + tf.transpose(c2) - 2.0 * xc

        labels = tf.cast(tf.argmin(dists, axis=1), tf.int32)                 # [N]

        # recompute centroids
        new_centroids = []
        for j in range(k):
            mask = tf.equal(labels, j)
            pts = tf.boolean_mask(x, mask)
            # handle empty cluster
            new_c = tf.cond(
                tf.shape(pts)[0] > 0,
                lambda: tf.reduce_mean(pts, axis=0),
                lambda: centroids[j],
            )
            new_centroids.append(new_c)
        centroids = tf.stack(new_centroids, axis=0)

    return labels, centroids


def main() -> None:
    log_path = Path("synthetic_system_logs.log")
    lines = load_lines(log_path)
    print("Loaded lines:", len(lines))

    # 1) Vectorize logs -> TF-IDF (character-level + ngrams)
    max_tokens = 8000
    vec = tf.keras.layers.TextVectorization(
        standardize=None,
        split="character",
        ngrams=5,
        max_tokens=max_tokens,
        output_mode="tf-idf",
    )
    text_ds = tf.data.Dataset.from_tensor_slices(lines).batch(256)
    vec.adapt(text_ds)

    X = vec(tf.constant(lines))             # [N, V] dense
    X = tf.cast(X, tf.float32)

    # Optional: L2 normalize (often helps KMeans)
    X = tf.linalg.l2_normalize(X, axis=1)

    # 2) Unsupervised clustering (KMeans in TF)
    k = 5
    labels, _ = tf_kmeans(X, k=k, iters=25, seed=42)
    labels_np = labels.numpy()

    # 3) Print a few examples per cluster (for naming)
    examples = defaultdict(list)
    for line, cid in zip(lines, labels_np):
        if len(examples[int(cid)]) < 5:
            examples[int(cid)].append(line)

    print("\n--- Cluster samples (for naming) ---")
    for cid in range(k):
        print(f"\n[Cluster {cid}]")
        for ex in examples[cid]:
            print("  ", ex)

    # 4) Supervised model: Keras MLP to predict cluster id
    y = tf.keras.utils.to_categorical(labels_np, num_classes=k)

    # split
    n = len(lines)
    idx = np.arange(n)
    rng = np.random.default_rng(42)
    rng.shuffle(idx)
    cut = int(n * 0.8)
    tr, te = idx[:cut], idx[cut:]

    X_tr, X_te = tf.gather(X, tr), tf.gather(X, te)
    y_tr, y_te = y[tr], y[te]

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(X.shape[1],)),
        tf.keras.layers.Dense(256, activation="relu"),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(k, activation="softmax"),
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="categorical_crossentropy",
        metrics=["accuracy"],
    )

    model.fit(
        X_tr, y_tr,
        validation_split=0.15,
        epochs=6,                # demo-speed; increase to 15-30 if you want
        batch_size=128,
        verbose=2
    )

    loss, acc = model.evaluate(X_te, y_te, verbose=0)
    print(f"\nTest accuracy (predicting cluster id): {acc:.4f}")

    # 5) Predict new line
    new_line = "2026-02-25T12:13:01Z ERROR service=gateway host=srv-02 region=eu-west-1 upstream timeout service=payments route=/v1/pay latency_ms=1800 code=504 trace=deadbeef proto=http/2"
    new_vec = vec(tf.constant([new_line]))
    new_vec = tf.linalg.l2_normalize(tf.cast(new_vec, tf.float32), axis=1)
    pred_cluster = int(tf.argmax(model.predict(new_vec, verbose=0), axis=1).numpy()[0])

    print("\nNew line predicted cluster:", pred_cluster)
    print("Line:", new_line)


if __name__ == "__main__":
    tf.get_logger().setLevel("ERROR")
    main()
