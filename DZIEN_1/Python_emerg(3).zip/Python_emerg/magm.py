from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Any, Iterable


@dataclass
class Spell:
    """Pojedyncze zaklęcie w arsenale Maga."""
    name: str
    mana_cost: int
    power: int
    fn: Callable[[Any], Any]

    def __call__(self, x: Any) -> Any:
        """Pozwala używać zaklęcia jak funkcji."""
        return self.fn(x)

    def __matmul__(self, other: "Spell") -> "Spell":
        """
        Operator kompozycji zaklęć.
        self @ other oznacza: najpierw self, potem other.
        """
        def composed(x: Any) -> Any:
            return other.fn(self.fn(x))

        return Spell(
            name=f"{self.name} » {other.name}",
            mana_cost=self.mana_cost + other.mana_cost,
            power=self.power + other.power,
            fn=composed,
        )


# --- Lokalne „proste” zaklęcia Maga ---

double_damage = Spell(
    name="Podwojenie mocy",
    mana_cost=3,
    power=5,
    fn=lambda x: x * 2,
)

fire_enchant = Spell(
    name="Ogniste Nasycenie",
    mana_cost=5,
    power=8,
    fn=lambda x: x + 10,
)

ice_shield = Spell(
    name="Lodowa Osłona",
    mana_cost=2,
    power=3,
    fn=lambda x: max(x - 3, 0),
)


# --- Funkcje „meta-magiczne” ---

def generate_combos(spells: Iterable[Spell], max_len: int = 3) -> list[Spell]:
    """
    Generuje wszystkie kombinacje zaklęć o długości 1..max_len
    używając jedynie operatora @ na Spell.
    """
    spells = list(spells)
    combos = []

    # długość 1
    combos.extend(spells)

    # długości 2..max_len
    current_level = spells
    for _ in range(2, max_len + 1):
        next_level = []
        for a in current_level:
            for b in spells:
                combo = a @ b
                combos.append(combo)
                next_level.append(combo)
        current_level = next_level

    return combos


def find_best_combo(target_power: int, mana_budget: int) -> Spell | None:
    """
    Szuka kombinacji, która:
    - ma moc >= target_power
    - mieści się w budżecie many
    - minimalizuje koszt many
    """
    base_spells = [double_damage, fire_enchant, ice_shield]
    combos = generate_combos(base_spells, max_len=3)

    feasible = [
        s for s in combos
        if s.power >= target_power and s.mana_cost <= mana_budget
    ]

    if not feasible:
        return None

    # emergentnie wybieramy najlepsze zaklęcie spośród tych,
    # o których nie pisaliśmy ręcznie
    return min(feasible, key=lambda s: s.mana_cost)


if __name__ == "__main__":
    best = find_best_combo(target_power=15, mana_budget=10)

    if best:
        print("== Najlepsza kombinacja Maga ==")
        print("Nazwa:", best.name)
        print("Koszt many:", best.mana_cost)
        print("Moc:", best.power)
        print("Efekt na wejściu 10:", best(10))
    else:
        print("Brak sensownej kombinacji w danym budżecie many.")
