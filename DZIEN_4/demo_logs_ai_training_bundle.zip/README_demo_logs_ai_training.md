# Demo szkoleniowe: logi -> (1) klasteryzacja nienadzorowana -> (2) klasyfikacja siecią neuronową

Ten pakiet jest gotowym przykładem na szkolenie:
- masz **surowy plik logów**,
- podejrzewasz, że w danych istnieje ok. **5 powtarzalnych „typów zdarzeń”**,
- ale **nie wiesz**, jak ręcznie wyekstrahować cechy i zrobić etykiety,
- więc:
  1) robisz **automatyczną reprezentację tekstu** (bez parserów),
  2) robisz **klasteryzację** (unsupervised) i oglądasz próbki,
  3) a potem uczysz **klasyfikator (MLP)**, który w runtime przypisuje nowe linie do klastra.

## Zawartość paczki

- `synthetic_system_logs.log`  
  Surowe logi (ok. 2500 linii). W tle generator tworzy 5 „ukrytych” typów zdarzeń (np. auth/bruteforce, DB timeout, upstream timeout/latency, disk/IO, cache/redis).

- `demo_logs_unsupervised_then_supervised.py`  
  Skrypt end-to-end:
  1) wektoryzacja tekstu (TF-IDF na znakowych n-gramach 3–5),
  2) klasteryzacja MiniBatchKMeans (k=5),
  3) wypisanie próbek z klastrów (do „nazwania” klastrów przez człowieka),
  4) uczenie klasyfikatora MLP (mała sieć neuronowa) do predykcji **ID klastra** dla nowych logów.

- `cluster_preview.json`  
  Po kilka przykładowych linii dla każdego klastra (żeby szybko pokazać, co jest w środku).

- `synthetic_system_logs_truth.csv` (opcjonalnie, „dla prowadzącego”)  
  To **nie jest potrzebne w scenariuszu produkcyjnym**. To plik z ukrytą klasą generatora, tylko do ewaluacji i pokazania, że clustering „złapał sens”.

## Jak uruchomić

W katalogu z plikami:

```bash
pip install -U scikit-learn numpy
python demo_logs_unsupervised_then_supervised.py
```

Skrypt:
- wypisze `Silhouette (sampled)` (metryka jakości klastrów),
- pokaże próbki dla każdego klastra,
- a potem wydrukuje raport z klasyfikacji (MLP),
- na końcu sklasyfikuje jedną przykładową nową linię logu.

## Jak to opowiedzieć na sali (krótko)

1) „Nie parsujemy logów ręcznie, bo format i wersje ciągle się zmieniają.”  
2) „Używamy reprezentacji tekstu odpornej na bałagan: n-gramy znakowe + TF-IDF.”  
3) „Najpierw clustering: odkrywamy grupy bez etykiet.”  
4) „Potem człowiek nadaje znaczenie klastrom.”  
5) „Na końcu uczymy sieć, żeby automatycznie przypisywała nowe zdarzenia do tych grup.”

Powodzenia 🚀
